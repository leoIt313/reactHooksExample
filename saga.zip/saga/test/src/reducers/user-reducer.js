import { ActionsTypes } from '../actions/actionTypes';

const INITIAL_STATE = {
    data: [],
    loginSucess: false
};

const reducer = (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case ActionsTypes.LOGIN_USER_RESPONSE:
            return { ...state, data: action.payload.data, loginSucess: true }
        default:
            return state;
    }
}

export default reducer;