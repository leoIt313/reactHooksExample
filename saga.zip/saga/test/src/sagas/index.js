import { all, takeLatest } from 'redux-saga/effects';
import { ActionsTypes } from '../actions/actionTypes';
import * as UserSagas from './user-sagas.js';

export default function* rootSaga() {
    return yield all([
        takeLatest(ActionsTypes.LOGIN_USER_REQUEST, UserSagas.DoLogin),
    ]);
}