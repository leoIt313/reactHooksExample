import { call, put } from 'redux-saga/effects';
import { loginResponse } from '../actions/loginAction'

export function* DoLogin(action) {
    try {
        yield put(loginResponse("Ok"));
    } catch (err) {
    }
}
