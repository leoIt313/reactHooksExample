export { default } from './myComponent';
