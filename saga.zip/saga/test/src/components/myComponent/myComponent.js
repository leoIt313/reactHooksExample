import React, { useState, useEffect } from 'react';
import './myComponent.css';
import formHook from '../../hooks/FormHook';
import { useSelector, useDispatch } from 'react-redux';
import { loginRequest } from '../../actions'

function MyComponent() {

  const dispatch = useDispatch();

  const state = useSelector(state => state.user);

  const { inputs, handleInputChange, handleSubmit } = formHook(submitForm);

  const [loginSucess, setLoginSucess] = useState(state.loginSucess);

  useEffect(() => {
    setLoginSucess(state.loginSucess);
  }, [state.loginSucess]);

  function submitForm() {
    dispatch(loginRequest(inputs))
  }

  return <div>
    <div>
      <label>Login</label>
      <input type="text" name="login" value={inputs.login} onChange={handleInputChange}></input>
    </div>

    <div>
      <label>Senha</label>
      <input type="password" name="password" value={inputs.password} onChange={handleInputChange}></input>
    </div>

    <div>
      <input type="button" value="logar" onClick={handleSubmit}></input>
    </div>

    <div> {loginSucess.toString()} </div>

  </div >
}

export default MyComponent;
