import { ActionsTypes } from './actionTypes';

export const loginRequest = (data) => ({
    type: ActionsTypes.LOGIN_USER_REQUEST,
    payload:
    {
        data: data,
    }
})

export const loginResponse = (data) => ({
    type: ActionsTypes.LOGIN_USER_RESPONSE,
    payload: {
        data: data
    }
});