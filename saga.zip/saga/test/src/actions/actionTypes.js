export const ActionsTypes = {
    LOGIN_USER_REQUEST: 'user:LOGIN_USER_REQUEST',
    LOGIN_USER_RESPONSE: 'user:LOGIN_USER_RESPONSE'
}
